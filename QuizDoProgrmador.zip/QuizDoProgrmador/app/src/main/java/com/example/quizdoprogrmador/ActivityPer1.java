package com.example.quizdoprogrmador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityPer1 extends AppCompatActivity {
    Button btnErro, btnErrod, btnCerto, btnErrot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_per1);

        btnErro = findViewById(R.id.btnErro);
        btnErrod = findViewById(R.id.btnErrod);
        btnCerto = findViewById(R.id.btnCerto);
        btnErrot = findViewById(R.id.btnErrot);

        btnErro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirErro();
            }
        });
        btnErrod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirErrod();
            }
        });
        btnCerto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPer2();
            }
        });
        btnErrot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirErrot();
            }
        });
    }
    private void abrirErro() {
        Intent janela = new Intent(this, ActivityErro.class);
        startActivity(janela);
    }
    private void abrirErrod() {
        Intent janelad = new Intent(this, ActivityErro.class);
        startActivity(janelad);
    }
    private void abrirPer2() {
        Intent janelaf = new Intent(this, ActivityPer2.class);
        startActivity(janelaf);
    }
    private void abrirErrot() {
        Intent janelat = new Intent(this, ActivityErro.class);
        startActivity(janelat);
    }
}