package com.example.quizdoprogrmador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityComo extends AppCompatActivity {
    Button btnIniciar2, btnVoltar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_como);

        btnIniciar2 = findViewById(R.id.btnIniciar2);
        btnVoltar2 = findViewById(R.id.btnVoltar2);

        btnIniciar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPer1();
            }
        });
        btnVoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }

    private void abrirPer1() {
        Intent jnaelag = new Intent(this, ActivityPer1.class);
        startActivity(jnaelag);
    }
    private void abrirMain() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}