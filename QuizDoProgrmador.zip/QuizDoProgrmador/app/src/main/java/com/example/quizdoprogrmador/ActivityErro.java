package com.example.quizdoprogrmador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityErro extends AppCompatActivity {
    Button btnReiniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_erro);

        btnReiniciar = findViewById(R.id.btnReiniciar);

        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }
    private void abrirMain() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}