package com.example.quizdoprogrmador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnIniciar, btnComoJogar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnIniciar = findViewById(R.id.btnIniciar);
        btnComoJogar = findViewById(R.id.btnComoJogar);

        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPer1();
            }
        });
        btnComoJogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirComo();
            }
        });
    }

    private void abrirPer1() {
        Intent janelag = new Intent(this,ActivityPer1.class);
        startActivity(janelag);
    }

    private void abrirComo() {
        Intent janela = new Intent(this, ActivityComo.class);
        startActivity(janela);
    }
}